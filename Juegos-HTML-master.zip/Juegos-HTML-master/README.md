<h1>Juegos creados solo con HTML, CSS y JAVASCRIPT</h1>
<ul>
  <li>TA-TE-TI: Finalizado</li>
  <li>SIMON DICE: Finalizado</li>
  <li>CLON DINOSAURIO CORRE: Por empezar...</li>
</ul>

<p>Podes probar los juegos <a href="https://geone-357.github.io/Juegos-HTML/">aqui</a></p>