import { Gasto } from './gasto';

describe('Gasto', () => {
  it('should create an instance', () => {
    expect(new Gasto()).toBeTruthy();
  });
});
